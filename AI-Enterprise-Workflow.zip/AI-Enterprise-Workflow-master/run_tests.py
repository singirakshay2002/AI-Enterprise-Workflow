import unittest
from tests.app_test import *
from tests.log_test import *
from tests.model_test import *

if __name__ == '__main__':
    unittest.main()
